import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { ProductService } from 'src/app/services/product.service';
import { IProduct } from 'src/app/types';

@Component({
  selector: 'app-product',
  templateUrl: './product.component.html',
  styleUrls: ['./product.component.css'],
})
export class ProductComponent implements OnInit {
  productId: number = 0;
  productDetails?: IProduct;

  constructor(
    private productService: ProductService,
    private route: ActivatedRoute
  ) {
    route.params.subscribe((params) => {
      this.productId = params['productId'];
    });
  }

  ngOnInit(): void {
    this.productDetails = this.productService.getSingleProduct(this.productId);
  }
}
